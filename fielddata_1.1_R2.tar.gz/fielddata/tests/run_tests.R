library(testthat)

test_dir('fielddata/inst/tests/')